:- consult('menu.pl').
:-consult('game.pl').

play:- mainMenu.
